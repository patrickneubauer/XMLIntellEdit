package at.ac.tuwien.big.xmltext.ecoretransform;

public interface SingleReferenceTransformation {

}
