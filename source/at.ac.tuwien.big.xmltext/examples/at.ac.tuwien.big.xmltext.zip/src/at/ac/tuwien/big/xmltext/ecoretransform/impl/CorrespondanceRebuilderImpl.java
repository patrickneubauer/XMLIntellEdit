package at.ac.tuwien.big.xmltext.ecoretransform.impl;

public class CorrespondanceRebuilderImpl {

}
