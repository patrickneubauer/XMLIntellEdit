package at.ac.tuwien.big.xmltext.ecoretransform;

import java.util.Collection;

import org.eclipse.emf.ecore.EObject;

public interface SingleObjectTransformation extends ObjectTransformation, SingleObjectTransformator {
	
}
