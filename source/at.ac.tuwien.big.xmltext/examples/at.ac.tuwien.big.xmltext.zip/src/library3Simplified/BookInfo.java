/**
 */
package library3Simplified;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Book Info</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see library3Simplified.library3SimplifiedPackage#getBookInfo()
 * @model
 * @generated
 */
public interface BookInfo extends EObject {
} // BookInfo
