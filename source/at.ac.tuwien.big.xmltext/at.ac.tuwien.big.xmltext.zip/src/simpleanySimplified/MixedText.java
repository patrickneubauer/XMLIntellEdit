/**
 */
package simpleanySimplified;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mixed Text</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see simpleanySimplified.simpleanySimplifiedPackage#getMixedText()
 * @model
 * @generated
 */
public interface MixedText extends MixedData {
} // MixedText
