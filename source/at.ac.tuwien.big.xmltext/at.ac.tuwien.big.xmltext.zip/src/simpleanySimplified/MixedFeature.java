/**
 */
package simpleanySimplified;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mixed Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see simpleanySimplified.simpleanySimplifiedPackage#getMixedFeature()
 * @model
 * @generated
 */
public interface MixedFeature extends MixedData {
} // MixedFeature
