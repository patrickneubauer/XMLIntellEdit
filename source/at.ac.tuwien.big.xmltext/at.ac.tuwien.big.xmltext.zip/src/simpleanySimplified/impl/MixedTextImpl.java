/**
 */
package simpleanySimplified.impl;

import org.eclipse.emf.ecore.EClass;

import simpleanySimplified.MixedText;
import simpleanySimplified.simpleanySimplifiedPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Mixed Text</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MixedTextImpl extends MixedDataImpl implements MixedText {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MixedTextImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return simpleanySimplifiedPackage.Literals.MIXED_TEXT;
	}

} //MixedTextImpl
